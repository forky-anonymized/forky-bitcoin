# Contact

## IRC

* [irc.libera.chat](irc://irc.libera.chat), channel `#btcd`

## Mailing Lists

* [btcd](mailto:btcd+subscribe@opensource.conformal.com): discussion of btcd and its packages.
* [btcd-commits](mailto:btcd-commits+subscribe@opensource.conformal.com): readonly mail-out of source code changes.

## Issue Tracker

The [integrated github issue tracker](https://github.com/btcsuite/btcd/issues)
is used for this project.
